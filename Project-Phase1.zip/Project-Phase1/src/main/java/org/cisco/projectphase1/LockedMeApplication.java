package org.cisco.projectphase1;

import org.cisco.projectphase1.Welcome.WelcomePage;

public class LockedMeApplication {
    public static void main(String[] args) {
        WelcomePage wp = new WelcomePage();
        wp.userPage();
        wp.GetUserChoice();

    }
}
