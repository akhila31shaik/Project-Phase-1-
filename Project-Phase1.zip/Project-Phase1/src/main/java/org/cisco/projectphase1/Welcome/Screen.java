package org.cisco.projectphase1.Welcome;

public interface Screen {
    public void Show();

    public void NavigateOption(int option);

    public void GetUserChoice();
}
